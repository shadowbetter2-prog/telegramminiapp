import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const POOL_ITEMS = [
  { name: '50 Coins', rarity: 'common', color: '#9ca3af' },
  { name: '200 Coins', rarity: 'common', color: '#9ca3af' },
  { name: '1 Gem', rarity: 'rare', color: '#3b82f6' },
  { name: '5 Gems', rarity: 'epic', color: '#a855f7' },
  { name: '10 Telegram Stars', rarity: 'legendary', color: '#eab308' }
];

export const CaseOpenModal = ({ selectedCase, onClose, onReward }) => {
  const [spinning, setSpinning] = useState(false);
  const [reelItems, setReelItems] = useState([]);
  const [wonItem, setWonItem] = useState(null);

  useEffect(() => {
    const generated = Array.from({ length: 50 }, () =>
      POOL_ITEMS[Math.floor(Math.random() * POOL_ITEMS.length)]
    );
    setReelItems(generated);
  }, [selectedCase]);

  const spinReel = () => {
    if (spinning) return;
    setSpinning(true);
    setWonItem(null);

    if (window.Telegram?.WebApp?.HapticFeedback) {
      window.Telegram.WebApp.HapticFeedback.impactOccurred('medium');
    }

    const randomIndex = Math.floor(Math.random() * 10) + 32;
    const reward = reelItems[randomIndex] || POOL_ITEMS[0];

    setTimeout(() => {
      setSpinning(false);
      setWonItem(reward);

      if (window.Telegram?.WebApp?.HapticFeedback) {
        window.Telegram.WebApp.HapticFeedback.notificationOccurred('success');
      }
      if (onReward) onReward(reward);
    }, 4500);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 z-50">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-sm text-center relative overflow-hidden shadow-2xl">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white font-bold text-xl">
          ✕
        </button>

        <div className="text-5xl mb-2">{selectedCase.icon}</div>
        <h3 className="text-xl font-extrabold text-white mb-1" style={{ color: selectedCase.color }}>
          {selectedCase.name}
        </h3>
        <p className="text-xs text-slate-400">Sandiqni ochish va yutuqni qo'lga kiritish</p>

        {/* Carousel Reel */}
        <div className="relative my-6 overflow-hidden border-2 border-amber-500/40 rounded-2xl bg-slate-950 h-28 flex items-center">
          <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-1 bg-amber-400 z-20 shadow-[0_0_12px_#f59e0b]" />

          <motion.div
            className="flex gap-2 px-4"
            animate={spinning ? { x: [-10, -3150] } : { x: 0 }}
            transition={{ duration: 4.5, ease: [0.15, 0.85, 0.35, 1.2] }}
          >
            {reelItems.map((item, idx) => (
              <div
                key={idx}
                className="w-20 h-20 flex-shrink-0 bg-slate-800/80 border rounded-xl flex flex-col items-center justify-center p-1"
                style={{ borderColor: item.color }}
              >
                <span className="text-xs font-bold text-white text-center">{item.name}</span>
                <span className="text-[9px] uppercase font-bold mt-1" style={{ color: item.color }}>
                  {item.rarity}
                </span>
              </div>
            ))}
          </motion.div>
        </div>

        {wonItem && (
          <div className="mb-4 animate-bounce">
            <span className="text-xs text-slate-400">Siz yutib oldingiz:</span>
            <h4 className="text-xl font-black text-amber-400">{wonItem.name}</h4>
          </div>
        )}

        <button
          onClick={spinReel}
          disabled={spinning}
          className="w-full py-3.5 rounded-2xl font-black text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:brightness-110 active:scale-95 transition-all disabled:opacity-50 shadow-lg shadow-amber-500/20"
        >
          {spinning ? 'Aylanmoqda...' : `Ochish (${selectedCase.price} ${selectedCase.currency})`}
        </button>
      </div>
    </div>
  );
};
