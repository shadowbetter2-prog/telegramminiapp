import React, { useState, useEffect } from 'react';
import { CASES_DATA } from './config/casesConfig';
import { CaseOpenModal } from './components/CaseOpenModal';
import { Sparkles, Gift, Wallet } from 'lucide-react';

export default function App() {
  const [balance, setBalance] = useState({ coins: 150, stars: 25 });
  const [activeTab, setActiveTab] = useState('cases');
  const [selectedCase, setSelectedCase] = useState(null);
  const [inventory, setInventory] = useState([]);

  useEffect(() => {
    if (window.Telegram?.WebApp) {
      window.Telegram.WebApp.ready();
      window.Telegram.WebApp.expand();
    }
  }, []);

  const handleReward = (rewardItem) => {
    setInventory((prev) => [rewardItem, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-24">
      {/* Header */}
      <div className="p-4 bg-slate-900/60 border-b border-slate-800/80 sticky top-0 backdrop-blur-md z-30 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-gradient-to-tr from-amber-400 to-yellow-600 rounded-xl flex items-center justify-center font-black text-slate-950 shadow-md shadow-amber-500/20">
            GB
          </div>
          <div>
            <h1 className="font-extrabold text-base leading-none text-white">GiftsBy</h1>
            <span className="text-[10px] text-slate-400">Telegram Mini App</span>
          </div>
        </div>

        {/* Balance Display */}
        <div className="flex items-center gap-2">
          <div className="bg-slate-800 border border-slate-700/60 rounded-full px-3 py-1 flex items-center gap-1.5 text-xs font-bold">
            <span>🪙</span>
            <span>{balance.coins}</span>
          </div>
          <div className="bg-slate-800 border border-slate-700/60 rounded-full px-3 py-1 flex items-center gap-1.5 text-xs font-bold text-amber-400">
            <span>⭐</span>
            <span>{balance.stars}</span>
          </div>
        </div>
      </div>

      {/* Main Content Areas */}
      <div className="p-4 max-w-md mx-auto">
        {activeTab === 'cases' && (
          <div>
            <div className="mb-4">
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Gift className="w-5 h-5 text-amber-400" /> Sandiqlar (Cases)
              </h2>
              <p className="text-xs text-slate-400">Sandiqlarni ochib noyob sovg'a va Star'lar yutib oling</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {CASES_DATA.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedCase(item)}
                  className={`bg-slate-900 border rounded-2xl p-4 flex flex-col items-center relative overflow-hidden active:scale-95 transition-all bg-gradient-to-b ${item.gradient} cursor-pointer`}
                >
                  <span
                    className="absolute top-2 right-2 text-[9px] font-black px-2 py-0.5 rounded-full text-white bg-slate-950/80 border border-slate-700"
                    style={{ color: item.color }}
                  >
                    {item.badge}
                  </span>
                  <div className="text-5xl my-3">{item.icon}</div>
                  <h3 className="font-bold text-sm text-center text-white mb-2">{item.name}</h3>
                  <button className="w-full py-1.5 rounded-xl bg-slate-800 text-amber-400 border border-slate-700 font-extrabold text-xs flex items-center justify-center gap-1">
                    <span>⭐</span> {item.price} {item.currency}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'tasks' && (
          <div>
            <h2 className="text-lg font-black text-white mb-1 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" /> Vazifalar (Tasks)
            </h2>
            <p className="text-xs text-slate-400 mb-4">Vazifalarni bajarib balansni to'ldiring</p>

            <div className="space-y-3">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-white">Telegram Kanalimizga a'zo bo'ling</h4>
                  <span className="text-xs text-amber-400 font-semibold">+50 Coins</span>
                </div>
                <button className="bg-amber-400 text-slate-950 px-3 py-1.5 rounded-xl font-bold text-xs">
                  A'zo bo'lish
                </button>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-white">Do'stlarni taklif qiling</h4>
                  <span className="text-xs text-amber-400 font-semibold">+2 ⭐ Stars</span>
                </div>
                <button className="bg-amber-400 text-slate-950 px-3 py-1.5 rounded-xl font-bold text-xs">
                  Ulashish
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'inventory' && (
          <div>
            <h2 className="text-lg font-black text-white mb-1 flex items-center gap-2">
              <Wallet className="w-5 h-5 text-amber-400" /> Inventar ({inventory.length})
            </h2>
            <p className="text-xs text-slate-400 mb-4">Sandiqlardan yutib olingan buyumlar to'plami</p>

            {inventory.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-sm">
                Sizda hali yutuqlar yo'q. Sandiqlarni ochib ko'ring!
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {inventory.map((item, idx) => (
                  <div key={idx} className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
                    <span className="text-xs font-bold text-white">{item.name}</span>
                    <p className="text-[10px] uppercase font-bold mt-1" style={{ color: item.color }}>
                      {item.rarity}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Sandiq Ochish Modali */}
      {selectedCase && (
        <CaseOpenModal
          selectedCase={selectedCase}
          onClose={() => setSelectedCase(null)}
          onReward={handleReward}
        />
      )}

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-slate-900/90 border-t border-slate-800 backdrop-blur-lg p-2 z-40">
        <div className="max-w-md mx-auto grid grid-cols-3 gap-1">
          <button
            onClick={() => setActiveTab('cases')}
            className={`py-2 rounded-xl flex flex-col items-center gap-1 font-bold text-xs transition-all ${
              activeTab === 'cases' ? 'bg-slate-800 text-amber-400' : 'text-slate-400'
            }`}
          >
            <Gift className="w-5 h-5" /> Sandiqlar
          </button>
          <button
            onClick={() => setActiveTab('tasks')}
            className={`py-2 rounded-xl flex flex-col items-center gap-1 font-bold text-xs transition-all ${
              activeTab === 'tasks' ? 'bg-slate-800 text-amber-400' : 'text-slate-400'
            }`}
          >
            <Sparkles className="w-5 h-5" /> Vazifalar
          </button>
          <button
            onClick={() => setActiveTab('inventory')}
            className={`py-2 rounded-xl flex flex-col items-center gap-1 font-bold text-xs transition-all ${
              activeTab === 'inventory' ? 'bg-slate-800 text-amber-400' : 'text-slate-400'
            }`}
          >
            <Wallet className="w-5 h-5" /> Inventar
          </button>
        </div>
      </div>
    </div>
  );
}
